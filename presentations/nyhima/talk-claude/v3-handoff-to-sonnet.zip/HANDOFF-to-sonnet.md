# Handoff — NYHIMA talk & deck

*From the Opus thread, for the Sonnet session that picks up the deck polish.*
*Author: Steve Schneider · NYHIMA Annual Conference, June 9, 2026.*

---

## What this project is

A ~50-minute conference talk for health-information professionals: **"Reading and Writing with AI: How We Live with a New Kind of Mind."** The thesis is the augmentation argument — AI is the latest in a 10,000-year line of thought-augmentations (spoken language → tokens → writing → alphabet → print → electronic → digital → pre-transformer AI), and the transformer/LLM is the genuine discontinuity because it *generates* rather than carries. Posture is **engagement with agency, not defense**. Tone is **collaborative wonder** — thinking *alongside* the room, never expert-at-distance. The talk is *read*, not spoken from memory.

A long Opus thread did the hard judgment work: inverted the thesis from a defensive "protect human thinking" frame to the augmentation frame; stripped all expert-distance language; reframed the cost section; built the close around Steve's real practice ("model in the loop"). **That work is settled. Do not re-litigate the argument or tone unless Steve asks.**

---

## Files (all in outputs)

1. **`nyhima-slides-text.html`** — THE DECK. Self-contained, two views:
   - **Read/edit view** (default): full spoken text down the page, each passage paired with a dashed rail showing the slide for that passage. This is also what Steve reads from.
   - **Present view**: press **P** or the ▶ button; full-screen slides; arrow keys / space to advance; Esc to exit. This is the audience surface.
   - The deck model is a JS array `SLIDES` near the bottom; the timeline data is the `TL` array; timeline mark positions are the `pos` array inside `timelineHTML()`.
2. **`nyhima-spoken-script.html`** — Steve's READING SCRIPT. Same text, chunked into 1–3 sentence breath-groups, 90% width, with inline dimmed slide-cues (▸). Has A−/A/A+/A++ size buttons. Prints clean. **Keep this in sync with any text changes to the deck** — they share the same words.
3. **`nyhima-talk-v3.md`** — the canonical text (markdown). Source of truth for *words*. If words change, change here too.
4. **`nyhima-deck-description.md`** — earlier prose spec of the deck. Reference only; the HTML supersedes it.

---

## Design tokens (v3.2 — locked)

- **Palette:** academic red `#8C1515` · ink `#1a1a1a` · grey `#666` · white paper. Red is the signature — used for the timeline fill, active dots, italic emphasis in fragments, and the title-slide subtitle.
- **Type:** Computer Modern / Latin Modern **serif** for titles and section headings; **monospace** (Courier-ish) for fragments and timeline labels. The two faces are deliberate — serif = human voice, mono = the machine. Do not unify them.
- **Sizing rule Steve set:** fragments are huge (`clamp(4rem,22vw,30rem)`); slide-1 subtitle is large and red; slide-2 timeline TITLE matches slide-1 title scale; timeline LABELS match slide-1 subtitle scale.

---

## Deck structure (what the audience sees)

1. Title (serif title + big red mono subtitle)
2–10. **Timeline, building one mark per advance** — 9 marks total, to-scale spacing (wide early, crowded modern). Final mark is **transformer · LLM (2017)** — the line ends on a *named technology*, not a date.
11. **November 30, 2022** — its own slide, AFTER the line resolves. (Moved off the timeline deliberately: the marks are all named techs, so a date was a category mismatch; it now lands as stark punctuation after the tech-line.)
12+. **Wonder fragments**, Sections 2–6, one concept-word/phrase per beat, mono, near-empty fields: *not faster — different · a different kind of mind · patterns, not facts · asleep between questions · the weight underneath — · or maybe — · the same fear, every time — · and every time, more · a someone, and not — · with · freer — · model in the loop · decide for yourself.* Ends dark.

Design principle throughout: **most of the screen is near-empty most of the time.** It's a read talk; the sparse type gives the eye somewhere to rest while Steve reads. Do not add density or decoration. No images (Steve declined eye-candy).

---

## OPEN ITEMS — what Sonnet should help with

1. **TIMELINE LABEL COLLISION (priority).** The modern end now has 5 marks crowded right (electronic/digital/pre-transformer AI/transformer at positions 67/78/88/97). Labels wrap but **may still overlap on Steve's screen — Claude is blind to the render, so Steve must report what he sees.** Likely fix: angle the labels, stagger up/down further, or widen spacing. Walk all 9 timeline build-steps in Present mode and fix overlaps.
2. **Fragment overflow check.** Long fragments ("the same fear, every time —", "a different kind of mind") at 22vw may wrap awkwardly or clip on a large screen. Verify each, size individually if one breaks badly.
3. **Slide-1 subtitle** — Steve has been pushing it bigger; confirm final size and whether red or near-black.
4. **Two-screen presenter mode (NOT YET BUILT).** Steve wants eyes-up delivery on two independent displays: laptop shows current slide + next slide + reading text; projector shows only the slide. The robust approach is a **separate popped-out audience window** Steve drags to the projector (not auto-detect, which fails in conference AV). Build only if Steve confirms his laptop can *extend* (not mirror) the display. **Steve must test the two-window flow on his actual laptop well before the room.** Paper is the fallback — also generate a clean print version of the script.
5. **Hinton attribution** — the talk paraphrases Hinton ("a genuinely different *form* of intelligence") rather than quoting. Steve should verify/finalize before podium. Search confirmed the framing is accurate (CSIRO/2024: "a new form of intelligence unlike our own") but keep it as paraphrase unless Steve sources an exact quote.

---

## Working method (important)

- **Edit by prompt/response.** Steve describes the change; you edit the file; he reopens to verify. He cannot see code and shouldn't have to.
- **You are blind to the rendered present-view.** For any visual/layout issue, Steve is your eyes — ask him what he sees, fix by description, have him re-check.
- **Version every change** in the top-bar label: this is **v3.2**; next is v3.3, etc.
- **Keep update-notes at the top of `nyhima-talk-v3.md`** when text changes (Steve's standing request).
- Steve signs `//steve`, uses "I" not "we", wants decisive recommendations not option-menus, declarative-professorial tone, no motivational framing.

---

*Opus handing off. The thinking is done; the polish is yours.*
