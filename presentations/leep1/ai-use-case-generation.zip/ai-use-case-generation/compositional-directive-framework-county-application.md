---
title: From Applied AI Literacy to County AI Use Cases — A Framework Bridge
date: 2026-05-31
project: county-ai (Herkimer)
type: synthesis / project-context primer
status: draft v1
source_material: Morrisville & Farmingdale "Applied AI Literacy" conversations (to be dumped into project context alongside this document)
purpose: Establish the compositional/directive framework as the conceptual spine for the county AI use-case deliverable, and resolve the open design questions (classify vs. tag, surfaces, model-in-the-loop) by showing they are one framework seen from different angles.
---

# From Applied AI Literacy to County AI Use Cases

## Why this document exists

The Herkimer use-case deliverable needs a spine. Fifty use cases without an organizing theory is a list; with one, it is an argument about where AI governance actually has to reach. That spine already exists — it was built for the Morrisville and Farmingdale "applied AI literacy" talks, in a different domain, for a different audience. This document carries it across.

The claim is simple and load-bearing: **county employees are the directive-AI population the Morrisville framework was built to describe.** Morrisville framed it pedagogically — what should we teach students who will meet AI as embedded, directive infrastructure in nursing, farming, and mechanics? The county frames it as policy — how do we govern employees who already meet AI that way, today, in benefits determination, law enforcement, public health, and records. Same population, same cognitive predicament, different institutional question. The framework transfers nearly intact.

## The framework, in brief

The applied-AI-literacy work produced a five-dimension taxonomy. Each use case (or learning scenario) is a point — a voxel — located in that space. The dimensions:

| Dimension | Values | What it captures |
|---|---|---|
| `cognitive_mode` | compositional · computational · directive | What kind of cognitive work the human is doing relative to the model |
| `ai_visibility` | explicit · embedded · invisible | Whether the person knows AI is involved |
| `output_type` | text · recommendation · analysis · action | What the model actually emits |
| `failure_mode` | perseveration · anchoring · automation_bias · fixation · overtrust · deskilling · delegation (and algorithm_aversion) | How the human-AI pairing characteristically goes wrong |
| `stakes` | reversible · consequential · irreversible | What it costs when it does |

The central distinction is `cognitive_mode`, and within it the contrast between two poles:

**Compositional.** The model generates text the human then works with — shapes, revises, argues against, signs. The output is material for further cognitive work. The human is the author and remains upstream of anything that matters. Dominant failure mode: *delegation* — handing off authorship and stopping thinking. This is the case nearly all AI-literacy pedagogy and nearly all organizational AI policy was built for.

**Directive.** The model generates a recommendation the human then acts on — or fails to override. The output is directive. The human is downstream of the model's judgment, often executing it. The cognitive work is no longer revision; it is judgment at the moment of deployment — the practiced pause before acting. Dominant failure modes: *perseveration* (continuing down the path the AI established even as conditions change), *automation_bias*, *fixation*, *overtrust*. This is the case almost nobody has built pedagogy or policy for.

(Computational — data → algorithm → analyst interprets — sits between them and matters less for the county frontline, though it is exactly the mode of the back-office analyst and the procured scoring engine. Hold it; it returns below.)

## The bridge: county employees are a directive-AI population

The Morrisville argument was that applied-program students will meet AI as directive infrastructure, and that compositional literacy mistrains them for it. The county version is stronger, because the county case is in three respects a *purer* instance of the directive predicament:

1. **The AI is frequently procured, not chosen.** A nursing student at least knows the clinical decision support tool is a tool. A county caseworker using a vendor's eligibility-scoring module, a deputy reading a vendor's risk flag, a clerk inside records software with an AI feature toggled on by the vendor — these people did not select the model, cannot inspect it, and often do not know it is there. `ai_visibility` slides from embedded toward invisible. The judgment is someone else's, made elsewhere, on someone else's training data.

2. **The stakes are routinely irreversible and public.** A benefits determination, an arrest, a child-welfare referral, a public-health flag. The directive × irreversible corner of the space — the pedagogically urgent cluster from the Morrisville work — is not a corner case for the county. It is the daily operating environment of several departments.

3. **There is no training and no permit.** The compositional world has scaffolding — the Learner's Permit, transcript-as-evidence, prompt critique. The county frontline has nothing. The employee meets the directive system cold, with no framework for the pause.

This is why a county AI policy built only for the compositional case — *don't paste confidential data into ChatGPT* — misses the highest-stakes, lowest-visibility uses entirely. Those rules govern the employee who knows they're using AI and is composing something. They say nothing to the employee who is executing a model's recommendation without knowing a model produced it. **The governance gap and the pedagogy gap are the same gap, at organizational scale.**

## Translation table

| Morrisville construct | County construct |
|---|---|
| Student who will meet directive AI in practice | Employee who meets directive AI now, on the job |
| "Teach the pause before acting" | "Require human validation before a directive output takes effect" |
| Failure mode named in a classroom | Failure mode written into (or absent from) policy |
| Disciplinary context (clinic, farm, shop) | Department (DSS, Sheriff, Public Health, Highway, Clerk) |
| Leave-behind artifact for faculty | Policy section + use-case exercise for staff |
| The voxel is a learning scenario | The voxel is a governed use case |

## Surfaces = `ai_visibility`, with a procurement layer

Earlier we listed the "surfaces" where county employees meet AI — tool, prompt, data, device, vendor. Those are not a separate taxonomy. They are `ai_visibility` made concrete for a workplace, with one addition the Morrisville frame didn't need:

- **Prompt surface** → *explicit.* Employee goes to ChatGPT/Claude and asks. Knows it's AI. Almost always compositional.
- **Tool surface** → *embedded.* AI feature inside software they already use (Copilot in Outlook, an AI assist in the case system). May or may not know it's there.
- **Device surface** → *explicit but ungoverned.* Personal phone, personal account — the DSS-worker-photographing-a-client case. Visibility is high to the employee, but the county's policy reach is near zero.
- **Data / vendor surface** → *embedded to invisible.* AI operating inside a procured system or an upstream pipeline. The employee sees an output, not a process. **This is the procurement layer** — and it is where directive use hides best, because the county bought the judgment along with the software.

The surface an employee is on largely determines their cognitive mode. Prompt surface pushes compositional; vendor surface pushes directive. That correlation is itself a finding the policy should exploit.

## Model-in-the-loop vs. human-in-the-loop, made precise

The framework dissolves the ambiguity in those phrases:

- **Human-in-the-loop = compositional.** The human is the loop's controlling node. The model assists; the human authors, reviews, and signs. The human is upstream of consequence.
- **Model-in-the-loop = directive.** The model's judgment is already in the loop before the human acts — embedded in a score, a flag, a queue, a setpoint. The human is downstream, and the live question is whether they can maintain an independent model of the situation while the AI is organizing what they see.

Your instinct to "focus on model-in-the-loop" is exactly the bet the whole deliverable rests on. The compositional cases are real but well-understood and largely self-governing. The directive cases are where the unexamined judgment lives — and where policy, if it is going to earn its keep, has to reach.

## What this means for the 50 use cases

Three design consequences follow directly.

**Tag, don't classify — because the tags are the voxel dimensions.** This resolves the earlier question. A use case is not a member of one bucket; it is a point in five-dimensional space. The DSS caseworker photographing a client to infer a race field is, simultaneously: directive (the model infers), device-surface (explicit-but-ungoverned), output_type = analysis-feeding-action, failure_mode = automation_bias + overtrust, stakes = irreversible. Classification would force a single label and flatten exactly the multidimensionality that makes the case worth discussing. Each use case therefore carries a tag set, one value per dimension.

**Compositional vs. directive is the primary axis, and the 5–10 uses per job split along it.** When generating AI uses for each county role, the compositional/directive split is the first cut — not a stylistic variation but the cut that determines the oversight the use requires. Compositional uses need composition-stage rules (data handling, disclosure, review-before-send). Directive uses need deployment-stage rules (validation before effect, override authority, logging of the model's judgment, vendor transparency). A policy that only writes the first kind of rule has not governed the second kind of use.

**The policy question each use case raises is `failure_mode × stakes`.** That product is what makes a use case interesting in the workshop and consequential in the policy. Low failure-likelihood × reversible = note it and move on. Automation_bias × irreversible = this is where the room should spend its time and where the policy needs teeth. The deck can be sequenced or color-weighted on this product to put attention where it belongs.

## The Ayush corollary: where judgment hides, at organizational scale

There is a lesson from a research pipeline worth stating here because it is the same phenomenon one level up. A beautifully engineered reference-ingestion pipeline turned out to contain a deeply buried file that scored every source 0–1.0 — a critical weighting that shaped every downstream inference. The author knew the output wasn't neutral but could not point to where the judgment was made; he and the model had built the architecture together, and the judgment had settled into a file nobody was looking at. Machine verification confirmed the pipeline *ran correctly*. It could not tell anyone whether the *judgment embedded in it was the right judgment* — because that judgment was invisible by construction.

That is the directive predicament exactly, and it is the county's predicament exactly. **Verification asks: did the process run as specified? Validation asks: were the judgments embedded in the process the right ones?** A procured eligibility engine can be perfectly verified and still encode a weighting nobody in the county has ever seen. The use-case deliverable, and the policy behind it, has to be built so that the validation question can be *asked* — which means surfacing the directive cases by name, locating where the model's judgment actually sits, and assigning a human the authority to interrogate it before it takes effect.

This is also the design principle for the human-in-the-loop protocol in the use-case generation task itself (a Cowork task with competing task masters): the checkpoint that matters is not "did the model produce 50 well-formed use cases" — a machine can verify that. It is "did a human with the judgment to recognize embedded values review the cases where the model was itself making a directive call." The task master has to be positioned where the judgment is, not where the output is.

## What this commits us to

- The use-case taxonomy *is* the voxel framework; the deck and the task spec inherit its dimensions as their tag schema.
- Compositional/directive is the primary cut for both the per-role generation and the policy mapping.
- The deck weights attention by `failure_mode × stakes`.
- The Cowork task's validation gates are placed at the directive/embedded/invisible cases, where verification is insufficient and human judgment is the only check.

## Open questions for Steve

1. Do we carry all five dimensions as tags on every use case, or lead with `cognitive_mode` + `ai_visibility` + `stakes` and treat `failure_mode` as the analyst's read rather than a generated tag?
2. Does the procurement/vendor surface get its own treatment in the deck, given it is where the county's exposure is largest and its visibility lowest?
3. For the workshop audience specifically: do we name the failure modes (perseveration, automation_bias) on the slides, or keep that vocabulary in the facilitator notes and let the cases carry it implicitly?
